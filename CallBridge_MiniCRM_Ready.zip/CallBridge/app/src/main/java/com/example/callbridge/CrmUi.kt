package com.example.callbridge

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private sealed interface CrmPage {
    data object Leads : CrmPage
    data class LeadForm(val lead: Lead? = null) : CrmPage
    data class History(val lead: Lead) : CrmPage
    data class Disposition(val lead: Lead, val durationSeconds: Int) : CrmPage
}

@Composable
fun CallBridgeApp(
    api: CrmApi,
    bridgeStatus: String,
    postCall: PostCallRequest?,
    onPostCallConsumed: () -> Unit,
    onCallLead: (Lead) -> Unit,
    onCheckBridge: () -> Unit,
) {
    var selectedTab by remember { mutableStateOf("crm") }

    LaunchedEffect(postCall?.nonce) {
        if (postCall != null) selectedTab = "crm"
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("OAKsphere CallBridge", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Mobile calling + mini CRM", style = MaterialTheme.typography.bodySmall)
                }
                if (selectedTab == "crm") Button(onClick = { selectedTab = "bridge" }) { Text("Bridge") }
                else Button(onClick = { selectedTab = "crm" }) { Text("CRM") }
            }
            Divider()

            if (selectedTab == "bridge") {
                BridgeScreen(bridgeStatus, onCheckBridge)
            } else {
                CrmRoot(
                    api = api,
                    postCall = postCall,
                    onPostCallConsumed = onPostCallConsumed,
                    onCallLead = onCallLead,
                )
            }
        }
    }
}

@Composable
private fun BridgeScreen(status: String, onCheckBridge: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Calling Bridge", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Text("The original CRM-to-phone polling service is still active.")
        Spacer(Modifier.height(20.dp))
        Button(onClick = onCheckBridge) { Text("Check Call Request") }
        Spacer(Modifier.height(16.dp))
        Text(status, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CrmRoot(
    api: CrmApi,
    postCall: PostCallRequest?,
    onPostCallConsumed: () -> Unit,
    onCallLead: (Lead) -> Unit,
) {
    var loggedIn by remember { mutableStateOf(api.hasSession()) }
    var page: CrmPage by remember { mutableStateOf(CrmPage.Leads) }
    var refreshKey by remember { mutableIntStateOf(0) }
    val rootScope = rememberCoroutineScope()

    LaunchedEffect(postCall?.nonce) {
        if (postCall != null) {
            page = CrmPage.Disposition(postCall.lead, postCall.durationSeconds)
            onPostCallConsumed()
        }
    }

    if (!loggedIn) {
        LoginScreen(api) { loggedIn = true; page = CrmPage.Leads; refreshKey++ }
        return
    }

    when (val current = page) {
        CrmPage.Leads -> LeadsScreen(
            api = api,
            refreshKey = refreshKey,
            onAdd = { page = CrmPage.LeadForm() },
            onEdit = { page = CrmPage.LeadForm(it) },
            onHistory = { page = CrmPage.History(it) },
            onCall = onCallLead,
            onLogout = {
                rootScope.launch {
                    withContext(Dispatchers.IO) { api.logout() }
                    loggedIn = false
                }
            },
            onSessionExpired = {
                api.clearSession(keepServer = true)
                loggedIn = false
            },
        )
        is CrmPage.LeadForm -> LeadFormScreen(
            api = api,
            lead = current.lead,
            onBack = { page = CrmPage.Leads },
            onSaved = { refreshKey++; page = CrmPage.Leads },
        )
        is CrmPage.History -> CallHistoryScreen(
            api = api,
            lead = current.lead,
            onBack = { page = CrmPage.Leads },
        )
        is CrmPage.Disposition -> DispositionScreen(
            api = api,
            lead = current.lead,
            initialDuration = current.durationSeconds,
            onBack = { page = CrmPage.Leads },
            onSaved = { refreshKey++; page = CrmPage.Leads },
        )
    }
}

@Composable
private fun LoginScreen(api: CrmApi, onLoggedIn: () -> Unit) {
    var server by remember { mutableStateOf(api.baseUrl) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Connect to OAKsphere CRM", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Use the same CRM account your recruiter uses on the web.")
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = server,
            onValueChange = { server = it },
            label = { Text("CRM server URL") },
            placeholder = { Text("https://your-crm-domain.com") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
        )
        if (error != null) {
            Spacer(Modifier.height(10.dp))
            Text(error!!, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (server.isBlank() || email.isBlank() || password.isBlank()) {
                    error = "Server URL, email and password are required."
                    return@Button
                }
                scope.launch {
                    loading = true; error = null
                    try {
                        withContext(Dispatchers.IO) { api.login(server, email, password) }
                        onLoggedIn()
                    } catch (e: Exception) {
                        error = e.message ?: "Login failed"
                    } finally {
                        loading = false
                    }
                }
            },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (loading) CircularProgressIndicator(modifier = Modifier.width(20.dp).height(20.dp), strokeWidth = 2.dp)
            else Text("Sign in")
        }
    }
}

@Composable
private fun LeadsScreen(
    api: CrmApi,
    refreshKey: Int,
    onAdd: () -> Unit,
    onEdit: (Lead) -> Unit,
    onHistory: (Lead) -> Unit,
    onCall: (Lead) -> Unit,
    onLogout: () -> Unit,
    onSessionExpired: () -> Unit,
) {
    var leads by remember { mutableStateOf<List<Lead>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var searchNonce by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshKey, searchNonce) {
        loading = true; error = null
        try {
            leads = withContext(Dispatchers.IO) { api.listLeads(search) }
        } catch (e: CrmApiException) {
            error = e.message
            if (e.statusCode == 401) onSessionExpired()
        } catch (e: Exception) {
            error = e.message ?: "Unable to load leads"
        } finally {
            loading = false
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Leads", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onLogout) { Text("Sign out") }
            Button(onClick = onAdd) { Text("+ Lead") }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                label = { Text("Search name / phone") },
                modifier = Modifier.weight(1f),
                singleLine = true,
            )
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { searchNonce++ }) { Text("Search") }
        }
        Spacer(Modifier.height(8.dp))

        when {
            loading -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            error != null -> Column(modifier = Modifier.padding(12.dp)) {
                Text(error!!, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { searchNonce++ }) { Text("Retry") }
            }
            leads.isEmpty() -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No leads found") }
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(leads, key = { it.id }) { lead ->
                    LeadCard(lead, onCall, onEdit, onHistory)
                }
            }
        }
    }
}

@Composable
private fun LeadCard(lead: Lead, onCall: (Lead) -> Unit, onEdit: (Lead) -> Unit, onHistory: (Lead) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(lead.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(lead.phone, style = MaterialTheme.typography.bodyMedium)
                    if (lead.company.isNotBlank()) Text(lead.company, style = MaterialTheme.typography.bodySmall)
                }
                Text(lead.status.replace('_', ' ').uppercase(), style = MaterialTheme.typography.labelSmall)
            }
            if (lead.notes.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(lead.notes, style = MaterialTheme.typography.bodySmall, maxLines = 2)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { onCall(lead) }) { Text("Call") }
                OutlinedButton(onClick = { onHistory(lead) }) { Text("History (${lead.callCount})") }
                TextButton(onClick = { onEdit(lead) }) { Text("Edit") }
            }
        }
    }
}

@Composable
private fun LeadFormScreen(api: CrmApi, lead: Lead?, onBack: () -> Unit, onSaved: () -> Unit) {
    var name by remember { mutableStateOf(lead?.name ?: "") }
    var phone by remember { mutableStateOf(lead?.phone ?: "") }
    var company by remember { mutableStateOf(lead?.company ?: "") }
    var notes by remember { mutableStateOf(lead?.notes ?: "") }
    var duplicateAck by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Text(if (lead == null) "Add Lead" else "Edit Lead", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Name *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(phone, { phone = it }, label = { Text("Phone *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(company, { company = it }, label = { Text("Company") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        if (lead == null) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { duplicateAck = !duplicateAck }) {
                Checkbox(checked = duplicateAck, onCheckedChange = { duplicateAck = it })
                Text("Allow creation if this phone already exists in my CRM scope")
            }
        }
        if (error != null) {
            Spacer(Modifier.height(10.dp))
            Text(error!!, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (name.isBlank() || phone.isBlank()) { error = "Name and phone are required."; return@Button }
                scope.launch {
                    loading = true; error = null
                    try {
                        withContext(Dispatchers.IO) {
                            if (lead == null) api.createLead(name, phone, company, notes, duplicateAck)
                            else api.updateLead(lead.id, name, phone, company, notes)
                        }
                        onSaved()
                    } catch (e: Exception) {
                        error = e.message ?: "Unable to save lead"
                    } finally { loading = false }
                }
            },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (loading) "Saving..." else "Save Lead") }
    }
}

@Composable
private fun CallHistoryScreen(api: CrmApi, lead: Lead, onBack: () -> Unit) {
    var history by remember { mutableStateOf<List<CallHistoryItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(lead.id) {
        try {
            history = withContext(Dispatchers.IO) { api.callHistory(lead.id) }
        } catch (e: Exception) {
            error = e.message ?: "Unable to load call history"
        } finally { loading = false }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Column {
                Text("Call History", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(lead.name, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(10.dp))
        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
            history.isEmpty() -> Text("No calls logged yet.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { it.id }) { call ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(call.outcomeLabel, fontWeight = FontWeight.SemiBold)
                            Text("Duration: ${formatDuration(call.durationSeconds)}")
                            Text(formatTimestamp(call.createdAt), style = MaterialTheme.typography.bodySmall)
                            if (call.notes.isNotBlank()) Text(call.notes, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DispositionScreen(
    api: CrmApi,
    lead: Lead,
    initialDuration: Int,
    onBack: () -> Unit,
    onSaved: () -> Unit,
) {
    var metadata by remember { mutableStateOf<DispositionMetadata?>(null) }
    var selected by remember { mutableStateOf<DispositionOption?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var duration by remember { mutableStateOf(initialDuration.toString()) }
    var notes by remember { mutableStateOf("") }
    var followupAt by remember { mutableStateOf("") }
    var followupReason by remember { mutableStateOf("Follow-up") }
    var closureReason by remember { mutableStateOf("") }
    var expectedJoining by remember { mutableStateOf(lead.expectedJoiningAt ?: "") }
    var interviewAt by remember { mutableStateOf("") }
    var interviewClient by remember { mutableStateOf(lead.company) }
    var interviewJob by remember { mutableStateOf("") }
    var interviewLocation by remember { mutableStateOf("") }
    var interviewContact by remember { mutableStateOf("") }
    var interviewType by remember { mutableStateOf("") }
    var interviewTypeMenu by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(lead.id) {
        try {
            val m = withContext(Dispatchers.IO) { api.dispositionMetadata(lead.id) }
            metadata = m
            selected = m.allOptions.firstOrNull()
            interviewType = m.interviewTypes.firstOrNull()?.value ?: "f2f"
        } catch (e: Exception) {
            error = e.message ?: "Unable to load CRM dispositions"
        } finally { loading = false }
    }

    if (loading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    val option = selected
    Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Column {
                Text("Call Disposition", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("${lead.name} • ${lead.phone}", style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(12.dp))

        if (error != null && metadata == null) {
            Text(error!!, color = MaterialTheme.colorScheme.error)
            return@Column
        }

        Text("Outcome", fontWeight = FontWeight.SemiBold)
        Box {
            OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                Text(option?.label ?: "Select CRM disposition")
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                metadata?.groups?.forEach { group ->
                    DropdownMenuItem(text = { Text(group.label, fontWeight = FontWeight.Bold) }, onClick = {})
                    group.options.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item.label) },
                            onClick = { selected = item; menuOpen = false; error = null },
                        )
                    }
                }
            }
        }
        if (option != null) {
            Text("CRM status after save: ${option.targetStatusLabel}", style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = duration,
            onValueChange = { if (it.all(Char::isDigit)) duration = it },
            label = { Text("Call duration (seconds)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )

        if (option?.requiresFollowup == true) {
            Spacer(Modifier.height(14.dp))
            Text("Next Follow-up *", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { followupAt = isoAfterHours(1) }) { Text("+1 Hour") }
                OutlinedButton(onClick = { followupAt = isoTomorrowAt10() }) { Text("Tomorrow 10 AM") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(followupAt, { followupAt = it }, label = { Text("Date/time ISO") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(followupReason, { followupReason = it }, label = { Text("Follow-up reason") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        }

        if (option?.requiresInterview == true) {
            Spacer(Modifier.height(14.dp))
            Text("Interview Details *", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(interviewAt, { interviewAt = it }, label = { Text("Interview date/time ISO") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(interviewClient, { interviewClient = it }, label = { Text("Client") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(interviewJob, { interviewJob = it }, label = { Text("Job") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            Box {
                OutlinedButton(onClick = { interviewTypeMenu = true }, modifier = Modifier.fillMaxWidth()) {
                    val label = metadata?.interviewTypes?.firstOrNull { it.value == interviewType }?.label ?: interviewType
                    Text("Interview type: $label")
                }
                DropdownMenu(expanded = interviewTypeMenu, onDismissRequest = { interviewTypeMenu = false }) {
                    metadata?.interviewTypes?.forEach { type ->
                        DropdownMenuItem(text = { Text(type.label) }, onClick = { interviewType = type.value; interviewTypeMenu = false })
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(interviewLocation, { interviewLocation = it }, label = { Text("Location (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(interviewContact, { interviewContact = it }, label = { Text("Contact person (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        }

        if (option?.requiresExpectedJoiningDate == true) {
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(expectedJoining, { expectedJoining = it }, label = { Text("Expected joining date/time ISO *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        }

        if (option?.requiresClosureReason == true) {
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(closureReason, { closureReason = it }, label = { Text("Closure / lost reason *") }, modifier = Modifier.fillMaxWidth())
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth(), minLines = 3)

        if (error != null) {
            Spacer(Modifier.height(10.dp))
            Text(error!!, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                val o = selected ?: return@Button
                if (o.requiresFollowup && followupAt.isBlank()) { error = "A next follow-up is required by the CRM."; return@Button }
                if (o.requiresClosureReason && closureReason.isBlank()) { error = "A closure reason is required by the CRM."; return@Button }
                if (o.requiresExpectedJoiningDate && expectedJoining.isBlank()) { error = "Expected joining date/time is required by the CRM."; return@Button }
                if (o.requiresInterview && (interviewAt.isBlank() || interviewClient.isBlank() || interviewJob.isBlank() || interviewType.isBlank())) {
                    error = "Interview date/time, client, job and type are required by the CRM."; return@Button
                }
                scope.launch {
                    saving = true; error = null
                    try {
                        val payload = JSONObject()
                            .put("outcome", o.value)
                            .put("duration_seconds", duration.toIntOrNull() ?: 0)
                            .put("notes", jsonNullable(notes))
                            .put("next_followup_at", jsonNullable(followupAt))
                            .put("next_followup_reason", if (followupAt.isNotBlank()) followupReason.trim().ifBlank { "Follow-up" } else null)
                            .put("closure_reason", jsonNullable(closureReason))
                            .put("expected_joining_date", jsonNullable(expectedJoining))
                        if (o.requiresInterview) {
                            payload.put("interview", JSONObject()
                                .put("scheduled_at", interviewAt.trim())
                                .put("client", interviewClient.trim())
                                .put("job", interviewJob.trim())
                                .put("type", interviewType)
                                .put("location", jsonNullable(interviewLocation))
                                .put("contact_person", jsonNullable(interviewContact))
                                .put("notes", JSONObject.NULL))
                        } else {
                            payload.put("interview", JSONObject.NULL)
                        }
                        withContext(Dispatchers.IO) { api.saveDisposition(lead.id, payload) }
                        onSaved()
                    } catch (e: Exception) {
                        error = e.message ?: "Unable to save disposition"
                    } finally { saving = false }
                }
            },
            enabled = !saving && selected != null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (saving) "Saving..." else "Save Disposition") }
        Spacer(Modifier.height(24.dp))
    }
}

private fun formatDuration(seconds: Int): String {
    val min = seconds / 60
    val sec = seconds % 60
    return if (min > 0) "${min}m ${sec}s" else "${sec}s"
}

private fun formatTimestamp(value: String): String = value.replace('T', ' ').replace("Z", " UTC")

private fun isoAfterHours(hours: Int): String {
    val cal = Calendar.getInstance()
    cal.add(Calendar.HOUR_OF_DAY, hours)
    return isoFormat(cal.time)
}

private fun isoTomorrowAt10(): String {
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, 1)
    cal.set(Calendar.HOUR_OF_DAY, 10)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    return isoFormat(cal.time)
}

private fun isoFormat(date: Date): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(date)

private fun jsonNullable(value: String): Any = if (value.trim().isBlank()) JSONObject.NULL else value.trim()
