package com.example.callbridge

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import com.example.callbridge.ui.theme.CallBridgeTheme
import kotlinx.coroutines.delay
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max


data class PostCallRequest(val lead: Lead, val durationSeconds: Int, val nonce: Long = System.nanoTime())
private data class ActiveMiniCall(val lead: Lead, val startedElapsed: Long)

class MainActivity : ComponentActivity() {

    // Existing Calling Bridge endpoint is deliberately preserved.
    private val serverUrl = "http://10.54.233.135:5000"
    private lateinit var crmApi: CrmApi

    private val bridgeStatus = mutableStateOf("Waiting for call request...")
    private val postCallRequest = mutableStateOf<PostCallRequest?>(null)
    private var permissionAction: (() -> Unit)? = null
    private var activeMiniCall: ActiveMiniCall? = null
    private var miniCallPaused = false

    private val callPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                permissionAction?.invoke()
            } else {
                bridgeStatus.value = "Phone permission is required to make SIM calls."
            }
            permissionAction = null
        }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        crmApi = CrmApi(this)

        setContent {
            CallBridgeTheme {
                val status by bridgeStatus
                val postCall by postCallRequest

                LaunchedEffect(Unit) {
                    while (true) {
                        checkPendingCall()
                        delay(3000)
                    }
                }

                CallBridgeApp(
                    api = crmApi,
                    bridgeStatus = status,
                    postCall = postCall,
                    onPostCallConsumed = { postCallRequest.value = null },
                    onCallLead = { requestMiniCrmCall(it) },
                    onCheckBridge = { startBridgePermissionCheck() },
                )
            }
        }
    }

    private fun requestMiniCrmCall(lead: Lead) {
        withCallPermission {
            activeMiniCall = ActiveMiniCall(lead, SystemClock.elapsedRealtime())
            miniCallPaused = false
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${lead.phone}"))
            startActivity(intent)
        }
    }

    override fun onPause() {
        super.onPause()
        if (activeMiniCall != null) miniCallPaused = true
    }

    override fun onResume() {
        super.onResume()
        val active = activeMiniCall
        if (active != null && miniCallPaused) {
            val seconds = max(0L, (SystemClock.elapsedRealtime() - active.startedElapsed) / 1000L).toInt()
            postCallRequest.value = PostCallRequest(active.lead, seconds)
            activeMiniCall = null
            miniCallPaused = false
        }
    }

    private fun startBridgePermissionCheck() {
        withCallPermission { checkPendingCall() }
    }

    private fun withCallPermission(action: () -> Unit) {
        val permission = Manifest.permission.CALL_PHONE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            permissionAction = action
            callPermissionLauncher.launch(permission)
        }
    }

    // Existing bridge polling/calling behavior remains intact.
    private fun checkPendingCall() {
        Thread {
            try {
                val url = URL("$serverUrl/api/pending-call")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                val response = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()

                val regex = """"phone_number"\s*:\s*"([^"]+)""".toRegex()
                val phoneNumber = regex.find(response)?.groupValues?.get(1)

                if (!phoneNumber.isNullOrEmpty()) {
                    runOnUiThread {
                        bridgeStatus.value = "Calling $phoneNumber from phone SIM..."
                        makeBridgeCall(phoneNumber)
                    }
                    completeCallRequest()
                }
            } catch (_: Exception) {
                // Silent polling failure matches the bridge's original always-on behavior.
            }
        }.start()
    }

    private fun makeBridgeCall(phoneNumber: String) {
        try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
            startActivity(intent)
        } catch (e: SecurityException) {
            bridgeStatus.value = "Grant phone permission, then tap Check Call Request."
        }
    }

    private fun completeCallRequest() {
        Thread {
            try {
                val url = URL("$serverUrl/api/call-complete")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.responseCode
                connection.disconnect()
                runOnUiThread { bridgeStatus.value = "Call request completed." }
            } catch (_: Exception) {
                // Preserve bridge operation even if completion acknowledgement fails.
            }
        }.start()
    }
}
